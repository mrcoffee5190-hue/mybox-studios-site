
# My Box Studios — Netlify + Stripe Bundle

Black/Gold branded storefront with Indie Music and Indie Movies, ready for Netlify deploy.
Includes Stripe Checkout + Webhook via Netlify Functions.

## Deploy steps
1) Link repo to Netlify (already done for you). In Netlify → Project configuration → Build & deploy:
   - Production branch: `main`
   - Build command: (blank)
   - Publish directory: `.`
   - Functions directory: `netlify/functions`

2) Commit these files to your GitHub repo (upload the contents of this folder).

3) Netlify → Site settings → Environment variables (LIVE):
   - STRIPE_SECRET_KEY = sk_live_...
   - STRIPE_PRICE_MUSIC_BASIC = price_xxx (your Stripe Price ID for music $0.99)
   - STRIPE_PRICE_VIDEO_BASIC = price_xxx (your Stripe Price ID for video $5.00)
   - STRIPE_WEBHOOK_SECRET = whsec_... (copied from Stripe after you create the endpoint)

4) Stripe Dashboard (LIVE) → Developers → Webhooks → Add endpoint
   - Endpoint URL: https://YOUR-SITE/.netlify/functions/stripe-webhook
   - Events: checkout.session.completed, payment_intent.succeeded, charge.refunded
   - Copy Signing secret (whsec_...) and paste into Netlify as STRIPE_WEBHOOK_SECRET.

5) Trigger a deploy. Visit /index.html to confirm.
