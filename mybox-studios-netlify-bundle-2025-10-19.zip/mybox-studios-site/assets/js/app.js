
async function renderGrid(url, mountId){
  const el = document.getElementById(mountId);
  if(!el) return;
  try{
    const res = await fetch(url,{cache:"no-store"});
    const items = await res.json();
    el.innerHTML = items.map(it => `
      <article class="card">
        <div class="thumb">${it.title[0] ?? '★'}</div>
        <div class="content">
          <h3>${it.title}</h3>
          <p>${it.desc}</p>
          <div class="price">$${it.priceUSD}</div>
        </div>
        <div class="actions">
          <button class="btn" data-id="${it.id}" data-price-key="${it.priceKey}">Buy Now</button>
        </div>
      </article>
    `).join("");
    el.querySelectorAll("button[data-id]").forEach(btn=>{
      btn.addEventListener("click", async ()=>{
        btn.disabled = true;
        try{
          const payload = {
            productId: btn.dataset.id,
            priceKey: btn.dataset.priceKey
          };
          const resp = await fetch("/.netlify/functions/create-checkout-session", {
            method: "POST",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify(payload)
          });
          const data = await resp.json();
          if(data && data.url){ window.location.href = data.url; }
          else { alert("Could not create checkout session. Check Stripe env vars."); }
        }catch(e){
          alert("Error: "+ e.message);
        }finally{
          btn.disabled = false;
        }
      });
    });
  }catch(e){
    el.innerHTML = `<div class="alert error">Failed to load catalog.</div>`;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if(document.getElementById("music-grid")) renderGrid("/data/music.json","music-grid");
  if(document.getElementById("movies-grid")) renderGrid("/data/movies.json","movies-grid");
  if(document.getElementById("featured")){
    // Load a mix of first 3 from each
    Promise.all([
      fetch("/data/music.json").then(r=>r.json()),
      fetch("/data/movies.json").then(r=>r.json())
    ]).then(([m1,m2])=>{
      const items = [...m1.slice(0,2), ...m2.slice(0,2)];
      const mountId="featured";
      const el = document.getElementById(mountId);
      el.innerHTML = items.map(it => `
        <article class="card">
          <div class="thumb">${it.title[0] ?? '★'}</div>
          <div class="content">
            <h3>${it.title}</h3>
            <p>${it.desc}</p>
            <div class="price">$${it.priceUSD}</div>
          </div>
          <div class="actions">
            <button class="btn" data-id="${it.id}" data-price-key="${it.priceKey}">Buy Now</button>
          </div>
        </article>
      `).join("");
      el.querySelectorAll("button[data-id]").forEach(btn=>{
        btn.addEventListener("click", async ()=>{
          btn.disabled = true;
          try{
            const payload = { productId: btn.dataset.id, priceKey: btn.dataset.priceKey };
            const resp = await fetch("/.netlify/functions/create-checkout-session", {
              method: "POST",
              headers: {"Content-Type":"application/json"},
              body: JSON.stringify(payload)
            });
            const data = await resp.json();
            if(data && data.url){ window.location.href = data.url; }
            else { alert("Could not create checkout session. Check Stripe env vars."); }
          }catch(e){ alert("Error: "+ e.message); }
          finally{ btn.disabled = false; }
        });
      });
    }).catch(()=>{});
  }
});
