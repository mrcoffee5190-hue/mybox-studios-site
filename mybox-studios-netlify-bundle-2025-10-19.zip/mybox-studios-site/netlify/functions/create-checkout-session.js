
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try{
    const { productId, priceKey } = JSON.parse(event.body || "{}");
    if(!priceKey){
      return { statusCode: 400, body: JSON.stringify({ error: "Missing priceKey" }) };
    }
    const priceId = process.env[priceKey];
    if(!priceId){
      return { statusCode: 400, body: JSON.stringify({ error: `Env var ${priceKey} not set` }) };
    }

    const baseUrl = process.env.URL || `https://${event.headers.host}`;

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${baseUrl}/success.html`,
      cancel_url: `${baseUrl}/cancel.html`,
      metadata: { productId }
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ url: session.url })
    };
  }catch(err){
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
